<?php

  include("Setup.php");
  echo "Initialisation reussie !<BR>";

?>