<?php
  ini_set('default_charset',"windows-1252");
  include("Parametres.php");

  $ListeGenres = $_GET['Listegenres'];
  $ListeRappeurs = $_GET['Listerappeurs'];
  $tri = $_GET['tri'];

  $id=mysqli_connect($host,$user,$pass);
  mysqli_select_db($id, $base) or die("Impossible de s�lectionner la base : $base");

  $NbGenres=sizeof($ListeGenres);
  if($NbGenres==0) echo "Vous devez s�lectionner au moins un genre<BR>\n";
  
  $NbRappeurs  =sizeof($ListeRappeurs);
  if($NbRappeurs==0) echo "Vous devez s�lectionner au moins un rappeur<BR>\n";

  echo"<BODY BGCOLOR=\"white\"   background=\"./images/bg.jpg\" style=\"font-size:80%;color:red\">";

  /*$resultat=mysqli_query($id,"SELECT * FROM ALBUM");
  $ligne = mysqli_fetch_assoc($resultat);
  $album   = $ligne["nom"];
  echo "$album";*/
  if(($NbGenres>0)&&($NbRappeurs>0))
    { 
    
      $requete="SELECT * FROM ALBUM WHERE ( genre='$ListeGenres[0]'";
      

      for($i=1;$i<$NbGenres;$i++)
        { $requete.=" OR genre='$ListeGenres[$i]'";
        }
        

      $requete.=") AND ( rappeur='$ListeRappeurs[0]'";
      
      
      for($i=1;$i<$NbRappeurs;$i++)
        { $requete.=" OR rappeur='$ListeRappeurs[$i]'";
        }
        
      $requete.=") ORDER BY `$tri` ASC;";
      
      $resultat=mysqli_query($id, "$requete");
      
      echo "<TABLE BORDER=1> 
            <TR><TH>Rappeur</TH><TH>Genre</TH><TH>Album</TH><TH>Annee</TH></TR>\n";
      for($i=0;$i<mysqli_num_rows($resultat);$i++) {
          $ligne = mysqli_fetch_assoc($resultat);
          $rappeur  = $ligne["rappeur"];
       	  $genre= $ligne["genre"];
          $album   = $ligne["nom"];
		  $annee = $ligne['annee'];;
		  
          echo "<TR><TD>$rappeur</TD><TD>$genre</TD><TD>$album</TD><TD>$annee</TD></TR>\n";
		  
        }
	  
      echo "</TABLE>\n";
	  
    }

?>