<?php
  ini_set('default_charset',"windows-1252");
  include("Initialiser.php");

  $resultat=mysqli_query($id, "SELECT * FROM rappeur;");
  $nb_rappeurs=mysqli_num_rows($resultat);
  for($i=0;$i<$nb_rappeurs;$i++)
    {
        $ligne_rappeur = mysqli_fetch_assoc($resultat);
        $rappeurs[$i]= $ligne_rappeur["nom"];
    }


  $resultat=mysqli_query($id, "SELECT * FROM genre;");
  $nb_genres=mysqli_num_rows($resultat);
  for($i=0;$i<$nb_genres;$i++) {
      $ligne_genre = mysqli_fetch_assoc($resultat);
      $genres[$i]= $ligne_genre["genre"];
  }

?>

<BODY BGCOLOR="white"   background="./images/bg.jpg" style="font-size:80%;color:red">
	<H1 align="CENTER">Gestion d'enregistrement des rappeurs</H1>
	

	<H2>Fonctionnalit�s d'acc�s</H2>
		


	<!-- 1ere ligne -->
	
	<FORM METHOD="GET" TARGET="Resultat" ACTION="ReInitialiser.php">
	<TABLE WIDTH="640" BORDER="1">
	<TR><TD>
		<TABLE BORDER="0">
		<TR>
		    <TD WIDTH="170" ALIGN="CENTER">&nbsp;</TD>
		    <TD WIDTH="230" ALIGN="CENTER">&nbsp;</TD>
		    <TD WIDTH="120" ALIGN="CENTER">&nbsp;</TD>
		    <TD WIDTH="110" ALIGN="CENTER">
		        <INPUT TYPE="SUBMIT" WIDTH="100" VALUE="  Initialiser  ">	
		    </TD>
		</TR>
		</TABLE>
	</TD></TR>
	</TABLE>	
	</FORM>


	
	<!-- 2eme ligne -->

	<FORM METHOD="GET" TARGET="Resultat" ACTION="Enregistrer.php">
	<TABLE WIDTH="640" BORDER="1">
	<TR><TD>

		<TABLE BORDER="0">
		<TR>
		    <TD WIDTH="170" ALIGN="LEFT">
		    	Rappeur :
		    	<SELECT NAME="rappeur" size="1">

<?php				
  foreach($rappeurs as $rappeur) 
    { echo "\t\t\t<OPTION>$rappeur</OPTION>\n";
    }
?>


			</SELECT>
		    </TD>
		    <TD WIDTH="230" ALIGN="LEFT">
		    	Genre :
		    	<SELECT NAME="genre" size="1">
	
				
<?php				
  foreach($genres as $genre) 
    { echo "\t\t\t<OPTION>$genre</OPTION>\n";
    }
?>


			</SELECT>
		    </TD>
		    <TD WIDTH="120" ALIGN="CENTER">		    
		        Album : <INPUT TYPE="TEXT" SIZE="10" MAXLENGTH="20" NAME="album">	
		    </TD>
		    	    
	
				
				
			</SELECT>
		    </TD>
		    <TD WIDTH="120" ALIGN="CENTER">		    
		        Annee : <INPUT TYPE="TEXT" SIZE="10" MAXLENGTH="4" NAME="annee">	
		    </TD>
		    
		    <TD WIDTH="110" ALIGN="CENTER">		    
		        <INPUT TYPE="SUBMIT" WIDTH="100" VALUE="Enregistrer">
		    </TD>
		</TR>
		</TABLE>
	</TD></TR>
	</TABLE>	
	</FORM>
		


        <!-- 3eme ligne -->

	<FORM METHOD="GET" TARGET="Resultat" ACTION="Supprimer.php">
	<TABLE WIDTH="640" BORDER="1">
	<TR><TD>
		<TABLE BORDER="0">
		<TR>
		    <TD WIDTH="170" ALIGN="LEFT">
		    	Rappeur :
		    	<SELECT NAME="rappeur" size="1">
				
<?php				
  foreach($rappeurs as $rappeur) 
    { echo "\t\t\t<OPTION>$rappeur</OPTION>\n";
    }
?>


		
			</SELECT>

		    
		    <TD WIDTH="110" ALIGN="CENTER">		    
		        <INPUT TYPE="SUBMIT" WIDTH="100" VALUE="Supprimer">	
		    </TD>
		</TR>
		</TABLE>
	</TD></TR>
	</TABLE>	
	</FORM>	
		                            
			
	<!-- 4eme ligne -->

	<FORM METHOD="GET" TARGET="Resultat" ACTION="Afficher.php">
	<TABLE WIDTH="640" BORDER="1">
	<TR><TD>
		<TABLE BORDER="0">
		<TR>
		    <TD WIDTH="70" VALIGN="TOP "ALIGN="LEFT">
		    	Rappeur :
		    </TD>
		    <TD WIDTH="100">


<?php				
  foreach($rappeurs as $rappeur) 
    { echo "<INPUT TYPE=\"CHECKBOX\" NAME=\"Listerappeurs[]\" VALUE=\"$rappeur\">$rappeur<BR>\n";


    }
?>

			
		    </TD>
			<TD WIDTH="80">
		    <TD WIDTH="80" VALIGN="TOP ALIGN="LEFT">
		    	        Genre :
		    </TD>
		    <TD WIDTH="150">
		    	
<?php				
  foreach($genres as $genre) 
    { echo "<INPUT TYPE=\"CHECKBOX\" NAME=\"Listegenres[]\" VALUE=\"$genre\">$genre<BR>\n";
    }
?>
	
		    </TD>
		    <TD WIDTH="30">&nbsp;</TD> 
		    <TD WIDTH="90" VALIGN="TOP" ALIGN="LEFT">Tri� par :<BR>
		        <INPUT NAME="tri" TYPE="RADIO" VALUE="rappeur"    CHECKED>Rappeur<BR>
           		<INPUT NAME="tri" TYPE="RADIO" VALUE="genre"         >Genre
		    </TD>
		    
		    <TD WIDTH="110" VALIGN="TOP" ALIGN="CENTER">		    
		        <INPUT TYPE="SUBMIT" WIDTH="100" VALUE="Afficher">	
		    </TD>
		</TR>
		</TABLE>
	</TD></TR>
	</TABLE>	
	</FORM>


</BODY>
</HTML>
