<?php
  ini_set('default_charset',"windows-1252");
  include("Parametres.php");

  $nom = $_GET['album'];
  $rappeur = $_GET['rappeur'];
  $genre = $_GET['genre'];
  $annee = $_GET['annee'];

  
  mysqli_select_db(mysqli_connect($host,$user,$pass), $base)
  or die("Impossible de s�lectionner la base : $base");

  $requete = "INSERT INTO ALBUM ('genre','rappeur','nom','annee') VALUES ('$genre', '$rappeur', '$nom', $annee;";
  $resultat=mysqli_query(mysqli_connect($host,$user,$pass), $requete);
  if ($resultat==False) {
	  echo "Mauvais";
  }
  $msg="Enregistrement de l'album de $rappeur de $annee dans le genre $genre : $nom";
  /*header("Location:index.php?msg=$msg");
  exit;*/
	

    
?>