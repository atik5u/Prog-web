<?php

  $host="localhost";
  $user="root";
  $pass="root";
  $base="album";


 ?>
