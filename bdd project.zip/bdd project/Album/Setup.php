<?php

  include("Parametres.php");

  $id=mysqli_connect($host,$user,$pass) or die("Impossible de se connecter au serveur : $host");

  $resultat=mysqli_query($id, "DROP DATABASE IF EXISTS $base");
  $resultat=mysqli_query($id, "CREATE DATABASE $base");
  mysqli_select_db($id, $base) or die("Impossible de s�lectionner la base : $base");




  $resultat=mysqli_query($id, "CREATE TABLE RAPPEUR 
                         (nom char(20) NOT NULL default '',
						 PRIMARY KEY (nom)
	  	       ) ;");

  
  $resultat=mysqli_query($id, "INSERT INTO RAPPEUR VALUES ('Drake');");
  $resultat=mysqli_query($id, "INSERT INTO RAPPEUR VALUES ('Eminem');");
  $resultat=mysqli_query($id, "INSERT INTO RAPPEUR VALUES ('Jay-Z');");
  $resultat=mysqli_query($id, "INSERT INTO RAPPEUR VALUES ('Kanye West');");
  $resultat=mysqli_query($id, "INSERT INTO RAPPEUR VALUES ('Travis Scott');");
  $resultat=mysqli_query($id, "INSERT INTO RAPPEUR VALUES ('Suicideboys');");

  
  $resultat=mysqli_query($id, "CREATE TABLE GENRE
                         (genre char(20) NOT NULL default '',
     		          PRIMARY KEY  (genre)
                       ) ;");

  
  $resultat=mysqli_query($id, "INSERT INTO GENRE VALUES ('Boom Bap');");
  $resultat=mysqli_query($id, "INSERT INTO GENRE VALUES ('Trap');");
  $resultat=mysqli_query($id, "INSERT INTO GENRE VALUES ('Cloud Rap');");

  
  $resultat=mysqli_query($id, "CREATE TABLE ALBUM 
                         ( genre   VARCHAR(225) NOT NULL default '',
    			   rappeur VARCHAR(225) NOT NULL default '',
  			   nom    VARCHAR(225)   NOT NULL default '',
			   annee int NOT NULL default 0,
  			   PRIMARY KEY  (nom)
		       ) ;");
  $resultat=mysqli_query($id, "INSERT INTO ALBUM VALUES ('Boom Bap', 'Jay-Z', 'All', '2002')");
  $resultat=mysqli_query($id, "INSERT INTO ALBUM VALUES ('Boom Bap', 'Eminem', 'MMLP', '2000')");
  $resultat=mysqli_query($id, "INSERT INTO ALBUM VALUES ('Trap', 'Travis Scott', 'Astroworld', '2018')");
  $resultat=mysqli_query($id, "INSERT INTO ALBUM VALUES ('Trap', 'Suicideboys', 'Grey', '2017')");
  $resultat=mysqli_query($id, "INSERT INTO ALBUM VALUES ('Cloud Rap', 'Kanye West', 'College Dropout', '2008')");  
?>