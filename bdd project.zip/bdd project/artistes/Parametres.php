<?php

  // Parametres de configuration de la connexion
  // -> permet de porter l'application en ne modifiant qu'une seule fois
  //	les param�tres de connexions � un serveur MySQL 

  $host="ess-mysql-etu.esstin.site.univ-lorraine.fr";
  $user="login";
  $pass="password";
  $base="user_login";


 ?>
